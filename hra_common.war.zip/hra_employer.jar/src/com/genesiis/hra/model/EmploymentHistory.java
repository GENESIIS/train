package com.genesiis.hra.model;

public class EmploymentHistory {

}
